import java.util.Scanner;

public class School {
	private Classroom[] classroom;
	
	public School(Classroom[] classroom) {
		this.classroom = classroom;
	}
	
	public String findStudents(String teachName, int stuID) {
		//sequential sort
		for (Classroom classroom:classroom) {
			if (classroom.getTeacherName().equals(teachName)) {
				//set up binary sort
				Student[] students = classroom.getStudents();
				int left = 0, right = students.length-1;
				
				while(left<=right) {
					int mid = left +((right-left)/2);
					if (students[mid].getStudentID()==stuID) {
						return students[mid].getStudentName();
					}
					//divides values in half
					else if(students[mid].getStudentID()<stuID) {
						left = mid + 1;
					}
					else {
						right = mid-1;
					}
				}
				return "student not found"; //if student is not id'd within the array
			}
		}
		return "student not found"; //if teacher is not found
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number of students: ");
		int stuNum = scanner.nextInt();
		scanner.nextLine();
		Student[] students = new Student[stuNum];
		int i=0;
		while (i < stuNum) {
			System.out.println("Enter student " + (i+1) + "'s name: ");
			//i is the student's id, this populates the students' info
			students[i] = new Student(scanner.nextLine(),i);
			i++;
		}
		
		System.out.println("Enter the teacher's name: ");
		String tName = scanner.nextLine();
		Classroom classroom = new Classroom(tName,students);
		
		School school = new School(new Classroom[] {classroom});
		System.out.println("Enter the ID of the student: ");
		System.out.println(school.findStudents(tName,scanner.nextInt()));
		scanner.close();
	}
}
