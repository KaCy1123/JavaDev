public class Classroom {
    private Student[] Student;
    private String teachName;
    
    public Classroom(String teacherName, Student[] Students) {
        this.Student=Students;
        this.teachName=teacherName;
    }
    
    public String getTeacherName() {
        return teachName;
    }
    
    public Student[] getStudents() {
        return Student;
    }
}