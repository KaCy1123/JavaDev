public class Student {
private String stuName;
private int stuID;
    public Student(String studentName,int studentID) {
        this.stuID=studentID;
        this.stuName=studentName;
        }
    public String getStudentName() {
        return stuName;
    }
    public int getStudentID() {
        return stuID;
    }
}